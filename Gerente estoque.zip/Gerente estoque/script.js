// Funções AJAX para comunicação com o back-end

function getProdutos() {
    fetch('/produtos')
        .then(response => response.json())
        .then(produtos => {
            renderProdutos(produtos);
        })
        .catch(error => {
            console.error('Erro ao carregar produtos:', error);
        });
}

function renderProdutos(produtos) {
    const produtosTable = document.getElementById('produtos-table').getElementsByTagName('tbody')[0];
    produtosTable.innerHTML = ''; // Limpa a tabela

    produtos.forEach(produto => {
        const row = produtosTable.insertRow();
        const idCell = row.insertCell();
        const nomeCell = row.insertCell();
        // ... (inserir as demais células para código, descrição, etc.)
        const acoesCell = row.insertCell();

        idCell.textContent = produto.id;
        nomeCell.textContent = produto.nome;
        // ... (preencher as demais células)
        acoesCell.innerHTML = `
            <button class="edit-btn" data-id="${produto.id}">Editar</button>
            <button class="delete-btn" data-id="${produto.id}">Excluir</button>
        `;
    });
}

// Funções para outras entidades (fornecedores, entregas, vendas)
// ... (Semelhantes à getProdutos() e renderProdutos(), mas com as respectivas tabelas)

// Eventos para os botões de adicionar
document.getElementById('add-produto').addEventListener('click', function() {
    // Abrir modal ou formulário para adicionar produto
    // ...
});

// ... (Eventos para botões de adicionar fornecedores, entregas e vendas)

// Eventos para botões de editar e excluir
document.getElementById('produtos-table').addEventListener('click', function(event) {
    if (event.target.classList.contains('edit-btn')) {
        // Abrir modal ou formulário para editar o produto
        // ...
    } else if (event.target.classList.contains('delete-btn')) {
        // Confirmar exclusão do produto
        // ...
        // Envie uma requisição DELETE para o back-end
        // ...
    }
});

// ... (Eventos para editar e excluir em outras tabelas)

// Carregar os dados das tabelas na inicialização
getProdutos();
// ... (Chamar as funções para carregar os dados de outras entidades)